package dao;

import entity.OrderDetail;

public class OrderDetailDao extends BaseDao<OrderDetail> {

}
