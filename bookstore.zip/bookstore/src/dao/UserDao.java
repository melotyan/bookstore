package dao;

import org.hibernate.Session;

import entity.User;

public class UserDao extends BaseDao<User> {

}
