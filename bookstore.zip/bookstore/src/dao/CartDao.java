package dao;

import java.util.ArrayList;
import java.util.List;

import entity.Cart;
import entity.CartId;

public class CartDao extends BaseDao<Cart> {
	
}
