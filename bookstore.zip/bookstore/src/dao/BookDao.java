package dao;

import entity.Book;

public class BookDao extends BaseDao<Book> {
	
	
	
}
