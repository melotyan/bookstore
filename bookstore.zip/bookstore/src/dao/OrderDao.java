package dao;

import entity.Order;

public class OrderDao extends BaseDao<Order> {

}
